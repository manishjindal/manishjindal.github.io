import java.util.TreeMap;

public class DBSystem {
		
	
	public static TreeMap<String, TreeMap<Integer, PageInfo>> tablemapping = new TreeMap<String, TreeMap<Integer, PageInfo>>();	
		
	public static void readConfig(String configFilePath) {
		DBConfig.loadConfig(configFilePath);
	}

	public static void populateDBInfo() {
		tablemapping = DBInit.createTablesMapping(DBConfig.listtablename);
	}
	


	public static String getRecord(String tableName, int recordId) {
		PageInfo pi = DBTools.retrievePageInfo(tableName, recordId);
		String record = DBTools.getRecord(tableName, pi, recordId);
		return record;
	}
	
	public static void insertRecord(String tableName, String record) {
		DBTools.insertRecord(tableName, record);
	}
	public static void main(String[] args) {
		DBSystem db = new DBSystem();
		db.readConfig("/tmp/config.txt");
		db.populateDBInfo();
		for(String p: tablemapping.keySet()) {
		//	System.out.println(p+" "+tablemapping.get(p)+"\n");
		}
	//	System.out.println(" "+tablemapping);
		//System.out.println(""+tablemapping);
		
		
		
		//System.out.println("List "+DBConfig.listtablename);
		//System.out.println("Map "+DBInit.tablemapping);
		//System.out.println("Rerieving page info "+DBTools.retrievePageInfo("employee", 5));
		//DBTools.insertRecord("countries","2: My New Record 2");
	/*
		DBTools.insertRecord("countries", "20: My New Record 20 hi this is manish jindal from jaipur.this is testing for insertion of A new record");
		DBTools.insertRecord("countries", "21: My New Record 20 hi this is manish jindal from jaipur.this is testing for insertion of A new record");
		DBTools.insertRecord("countries", "22: My New Record 20 hi this is manish jindal from jaipur.this is testing for insertion of A new record");
		DBTools.insertRecord("countries", "23: My New Record 20 hi this is manish jindal from jaipur.this is testing for insertion of A new record");
		DBTools.insertRecord("countries", "24: My New Record 20 hi this is manish jindal from jaipur.this is testing for insertion of A new record");
		DBTools.insertRecord("countries", "25: My New Record 20 hi this is manish jindal from jaipur.this is testing for insertion of A new record");

		
		
		String record = db.getRecord("countries", 5);
		System.out.println("Record "+record);
		
		 record = db.getRecord("countries", 10);
		System.out.println("Record "+record);
		
		 record = db.getRecord("countries", 15);
		System.out.println("Record "+record);
		
		 record = db.getRecord("countries", 18);
		System.out.println("Record "+record);
		
		
		 record = db.getRecord("countries", 22);
		System.out.println("Record "+record);
		
		record = db.getRecord("countries", 45);
		System.out.println("Record "+record);
		
		record = db.getRecord("countries", 46);
		System.out.println("Record "+record);
		
		record = db.getRecord("countries", 48);
		System.out.println("Record "+record);
		
		record = db.getRecord("countries", 49);
		System.out.println("Record "+record);
		*/
		
/*		DBTools.insertRecord("employee", "21: My New Record 21");
		DBTools.insertRecord("employee", "22: My New Record 22");
		DBTools.insertRecord("employee", "23: My New Record 23");
		DBTools.insertRecord("employee", "24: My New Record 24");
		DBTools.insertRecord("employee", "25: My New Record 25");
		
		db.getRecord("employee", 19);
		db.getRecord("employee", 20);
		db.getRecord("employee", 3);
		db.getRecord("employee", 12);
		db.getRecord("student", 5);
		
		db.getRecord("student", 8);
		db.getRecord("employee", 2);
		db.getRecord("employee", 4);
		db.getRecord("student", 19);
		db.getRecord("employee", 10);
		db.getRecord("student", 13);
		db.getRecord("employee", 16);
		*/
		//System.out.println("<------------------------------------------>");
	
		
		
	}
}
