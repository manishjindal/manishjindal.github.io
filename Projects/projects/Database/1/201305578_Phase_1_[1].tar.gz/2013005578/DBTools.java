import java.io.File;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.TreeMap;

public class DBTools {

	static DBLru lru = new DBLru();

	public static PageInfo retrievePageInfo(String tableName, int recordId) {
		TreeMap<Integer, PageInfo> mapPageInfo = DBInit.tablemapping
				.get(tableName);
		PageInfo pi = getPageInfo(mapPageInfo, recordId);
		return pi;
	}

	/**
	 * To get the id of the Page from the record id
	 * 
	 * @param mapPageInfo
	 * @param recordid
	 * @return
	 */
	public static PageInfo getPageInfo(TreeMap<Integer, PageInfo> mapPageInfo,
			int recordid) {
		// //System.out.println("FInding "+recordid);
		PageInfo pi = new PageInfo();
		for (Map.Entry<Integer, PageInfo> entry : mapPageInfo.entrySet()) {
			pi = entry.getValue();
			// //System.out.println("Looking in "+pi);
			// //System.out.println("Start at "+pi.getStartrecordid());
			// //System.out.println("End at "+pi.getEndrecordid());

			if ((recordid >= pi.getStartrecordid())
					&& (recordid <= pi.getEndrecordid())) {
				// //System.out.println("Found "+recordid+ " at "+pi);
				return pi;
			}
		}
		return pi;
	}

	public static String getRecord(String tablename, PageInfo pi, int recordid) {
		String tablepage = tablename + "_" + pi.getPageno();
		if (pi.isInmemory()) {
			lru.updatePageintoMemory(tablename, pi.getPageno(), true);
		} else {
			lru.addPageintoMemory(tablename, pi, false, true);
		}
		String record = lru.getRecordFromPageInMemory(tablepage, recordid);
		//System.out.println("Record " + record);
		return record;
	}

	public static File getTableFile(String tablename) {
		StringBuffer filepath = new StringBuffer();
		filepath.append(DBConfig.pathforData);
		filepath.append(File.separator);
		filepath.append(tablename);
		filepath.append(DBConfig.tablefileext);
		File dbfile = new File(filepath.toString());
		return dbfile;
	}

	public static void insertRecord(String tablename, String record) {
		PageInfo pi = getLastPage(tablename);
		addRecordtoTableFile(tablename, record);
		if (lru.isSpaceinPage(pi, record)) {
			if (pi.isInmemory()) {
				lru.updatePageintoMemory(tablename, pi.getPageno(), false);
			} else {
				lru.addPageintoMemory(tablename, pi, false, false);
			}
			lru.addRecordtoMemPage(tablename, pi, record, false);
		} else {
			PageInfo newpi = lru.addNewPage(tablename);
			lru.addPageintoMemory(tablename, newpi, true, false);
			lru.addRecordtoMemPage(tablename, newpi, record, true);
		}
	}

	public static void addRecordtoTableFile(String tablename, String record) {
		try {

			FileOutputStream fos = new FileOutputStream(
					getTableFile(tablename), true);
			byte[] b = record.getBytes();
			fos.write(b, 0, record.length());
			fos.write('\n');
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static PageInfo getLastPage(String tablename) {

		TreeMap<Integer, PageInfo> inner = new TreeMap<Integer, PageInfo>();
		PageInfo pi = null;
		if (DBInit.tablemapping.containsKey(tablename)) {
			inner = DBInit.tablemapping.get(tablename);
			pi = inner.get(inner.lastKey());
		}

		return pi;
	}
}
