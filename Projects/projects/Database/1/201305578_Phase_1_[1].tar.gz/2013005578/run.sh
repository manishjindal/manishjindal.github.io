`javac *.java`
