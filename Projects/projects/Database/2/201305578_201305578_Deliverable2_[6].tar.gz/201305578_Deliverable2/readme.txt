JDK Version Required : 1.6
External Library used : General SQL Parser
External Library Path : 201305578_src/gsp.jar

Main Class to Execute: DBSystem
Main Class Location  : 201305578_src
Command Line Argument: Argument1: config file path Argument2: input file location
