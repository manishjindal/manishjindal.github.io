javac -cp ".:201305578_src/gsp.jar" 201305578_src/*.java 2>/dev/null
java -cp "201305578_src:201305578_src/gsp.jar" DBSystem "$1" "$2" 2>/dev/null
